#include "ClassName.h"

ClassName::ClassName()
{
}

ClassName::~ClassName()
{
}

