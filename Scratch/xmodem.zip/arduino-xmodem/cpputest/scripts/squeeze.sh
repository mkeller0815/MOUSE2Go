#!/bin/sed -f
s/[ 	][ 	]*/ /g
