
#include "CppUTest/TestHarness_c.h"

void functionWithUnusedParameter(void* PUNUSED(unlessParamater))
{

}
